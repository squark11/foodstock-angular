﻿namespace FoodStock.Infrastructure.DAL;

internal class PostgresOptions
{
    public string ConnectionString { get; set; }
}
