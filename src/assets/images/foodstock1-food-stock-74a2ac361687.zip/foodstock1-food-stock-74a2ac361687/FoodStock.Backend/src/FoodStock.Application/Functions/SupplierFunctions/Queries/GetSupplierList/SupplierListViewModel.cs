﻿namespace FoodStock.Application.Functions.SupplierFunctions.Queries.GetSupplierList;

public sealed record SupplierListViewModel
{
    public Guid Id { get; set; }
    public string Name { get; set; }
}
