﻿namespace FoodStock.Application.Functions.SupplierFunctions.Queries.GetSupplierDetail;

public sealed record SupplierDetailViewModel
{
    public Guid Id { get; set; }
    public string Name { get; set; }
}
