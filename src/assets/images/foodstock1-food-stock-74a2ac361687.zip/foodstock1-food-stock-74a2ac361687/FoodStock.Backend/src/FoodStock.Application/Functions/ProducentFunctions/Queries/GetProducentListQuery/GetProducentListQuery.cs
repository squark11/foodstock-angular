﻿using MediatR;

namespace FoodStock.Application.Functions.ProducentFunctions.Queries.GetProducentListQuery;

public class GetProducentListQuery : IRequest<List<ProducentListViewModel>>
{

}
