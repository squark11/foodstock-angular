﻿using AutoMapper;
using FoodStock.Application.Repositories;
using MediatR;

namespace FoodStock.Application.Functions.ProductFunctions.Queries;

public class GetProductListByCategoryIdHandler : IRequestHandler<GetProductListByCategoryIdQuery, List<ProductListByCategoryIdViewModel>>
{
    private readonly IProductRepository _productRepository;
    private readonly IMapper _mapper;

    public GetProductListByCategoryIdHandler(IProductRepository productRepository, IMapper mapper)
    {
        _productRepository = productRepository;
        _mapper = mapper;
    }
    
    public async Task<List<ProductListByCategoryIdViewModel>> Handle(GetProductListByCategoryIdQuery request, CancellationToken cancellationToken)
    {
        var products = await _productRepository.GetAllOrderByExpirationDateAscAsync();
        var productsByCategoryId = products.Where(x => x.CategoryId == request.CategoryId);
        return _mapper.Map<List<ProductListByCategoryIdViewModel>>(productsByCategoryId);
    }
}
