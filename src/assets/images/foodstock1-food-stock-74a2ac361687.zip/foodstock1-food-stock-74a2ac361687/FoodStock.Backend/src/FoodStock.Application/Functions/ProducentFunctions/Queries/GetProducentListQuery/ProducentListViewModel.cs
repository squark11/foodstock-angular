﻿namespace FoodStock.Application.Functions.ProducentFunctions.Queries.GetProducentListQuery;

public sealed record ProducentListViewModel
{
    public Guid Id { get; set; }
    public string Name { get; set; }
}
